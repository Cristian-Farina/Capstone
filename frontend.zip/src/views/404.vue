<template>
  <section class="page-404">
    <h1 class="title">
      404
    </h1>
  </section>
</template>

<script>
import Vue from 'vue';

export default Vue.extend({
});
</script>
